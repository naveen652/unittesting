const { isPrime } = require('./isPrime');

const findPrimes = (x, y) => {
    let primes = []
    for (let i = x; i < y; i++) {
        if (isPrime(i)) {
            primes.push(i);
        }
    }
    return primes;
}

module.exports = { findPrimes };
