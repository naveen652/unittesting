const assert = require('assert');
console.log(assert);