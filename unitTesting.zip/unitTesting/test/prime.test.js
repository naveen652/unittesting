const { isPrime } = require('../src/isPrime');
const {findPrimes} = require('../src/findPrimes');
const assert = require('assert');


it('should run true for 2', () => {
    const result = isPrime(2);
    assert.equal(true, result);
})


it('should run false for 15', () => {
    const result = isPrime(15);
    assert.equal(false, result);
})

it('should be more than 4 primes under 10', () => {
    const result = findPrimes(1, 10);
    assert.equal(true, result.length)
})